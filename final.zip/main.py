from model import run, run2, run3

run('train.csv', 'test.csv', 'out4.csv')